<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php

class User extends CI_Controller {

public function __construct(){

        parent::__construct();
  			$this->load->helper('url');
  	 		$this->load->model('user_model');
        $this->load->library('session');

}

public function index()
{
	$this->load->view('welcome_message');
}
// public function register_user(){
//
//       $user=array(
//       'user_name'=>$this->input->post('user_name'),
//       'user_email'=>$this->input->post('user_email'),
//       'user_password'=>md5($this->input->post('user_password')),
//       'user_age'=>$this->input->post('user_age'),
//       'user_mobile'=>$this->input->post('user_mobile')
//         );
//         print_r($user);
//
// $email_check=$this->user_model->email_check($user['user_email']);
//
// if($email_check){
//   $this->user_model->register_user($user);
//   $this->session->set_flashdata('success_msg', 'Registered successfully.Now login to your account.');
//   redirect('user/login_view');
//
// }
// else{
//
//   $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
//   redirect('user');
//
//
// }
//
// }

public function login_view(){

$this->load->view("login.php");

}

function login_user(){
  $user_login=array(

  'user_email'=>$this->input->post('user_email'),
  'user_password'=>($this->input->post('user_password'))

    );

    $data=$this->user_model->login_user($user_login['user_email'],$user_login['user_password']);
      if($data)
      {

        $this->session->set_userdata('user_id',$data['user_id']);
        $this->session->set_userdata('user_email',$data['user_email']);
        $this->session->set_userdata('user_name',$data['user_name']);
        $this->session->set_userdata('user_role',$data['user_role']);
       $this->session->set_userdata('user_department',$data['user_department']);
       if($data['user_role']=='Admin')
        {
            $this->load->view('admin_profile.php');
         }
        else
        {
          $this->list_folders();
          //$this->user_profile();
          //$this->name_folders();
        }

      }
      else{
        $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
        $this->load->view("login.php");

      }


}

function user_profile(){

$this->load->view('admin_profile.php');

}
public function user_logout(){

  $this->session->sess_destroy();
  redirect('user/login_view', 'refresh');
}
// user table list
public function details()
	{

		$data['user']=$this->user_model->get_all_users();
		$this->load->view('user_details',$data);
	}

  public function add_user()
		{
			$data = array(
					'user_name' => $this->input->post('user_name'),
					'user_email' => $this->input->post('user_email'),
					'user_password' => $this->input->post('user_password'),
					'user_role' => $this->input->post('user_role'),
          'user_department' => $this->input->post('user_department'),
				);
			$insert = $this->user_model->add_user($data);
			echo json_encode(array("status" => TRUE));
		}
		public function ajax_edit($id)
		{
			$data = $this->user_model->get_by_id($id);



			echo json_encode($data);
		}
// update user
		public function user_update()
	{
		$data = array(
				'user_name' => $this->input->post('user_name'),
				'user_email' => $this->input->post('user_email'),
				'user_password' => $this->input->post('user_password'),
				'user_role' => $this->input->post('user_role'),
        'user_department' => $this->input->post('user_department'),
			);
		$this->user_model->user_update(array('user_id' => $this->input->post('user_id')), $data);
		echo json_encode(array("status" => TRUE));
	}
// delete user
	public function user_delete($id)
	{
		$this->user_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

  public function name_folders()
  {
    $data['department']=$this->user_model->get_department();
    // $this->load->view('user_profile',$data);
    $this->load->view('folder',$data);
    //  $this->create_folder();

  }
 public function create_folder()
  {
    $folder_name = $_POST['folder'];
    $department_name = $_POST['department'];
$uid = $this->session->userdata('user_id');

        $mydir=$folder_name;
        $old = umask(0);
        mkdir($mydir, 0777, true);
        umask($old);

		  $path="/var/www/html/CI/project/$mydir/";
      $fold = array('department' => $department_name,'folder_path' => $path,'uid' => $uid,'folder_name' => $folder_name);
   $this->user_model->create_folder($fold);
         $this->gett();

   }
public function list_folders()
{
  $data['department']=$this->user_model->list_folders();
  $this->user_model->list_folders();
  $this->load->view('folder_list',$data);

}

public function gett()
{
  $uid1 = $this->session->userdata('user_id');
  $data['abc']=$this->user_model->get_folder($uid1);
  $this->load->view('list',$data);
}
public function list_file()
{
  $postid = $this->uri->segment(3);
  //$filename = $myfilename;
$data['xyz']=$this->user_model->list_files($postid);
   $this->load->view('file_list',$data);


}

// public function save_file()
// {
//   $target_dir = "/var/www/html/CI/project/$filename/";
// $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
// $uploadOk = 1;
// $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// // Check if image file is a actual image or fake image
// if(isset($_POST["submit"])) {
//     $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
//     if($check !== false) {
//         echo "File is an image - " . $check["mime"] . ".";
//         $uploadOk = 1;
//     } else {
//         echo "File is not an image.";
//         $uploadOk = 0;
//     }
// }
// // Check if file already exists
// if (file_exists($target_file)) {
//     echo "Sorry, file already exists";
//     $uploadOk = 0;
// }
// // Check file size
// if ($_FILES["fileToUpload"]["size"] > 500000) {
//     echo "Sorry, your file is too large.";
//     $uploadOk = 0;
// }
// // Allow certain file formats
// if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
// && $imageFileType != "gif" ) {
//     echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
//     $uploadOk = 0;
// }
// // Check if $uploadOk is set to 0 by an error
// if ($uploadOk == 0) {
//     echo "Sorry, your file was not uploaded.";
// // if everything is ok, try to upload file
// } else {
//     if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
//         echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
//     } else {
//         echo "Sorry, there was an error uploading your file.";
//     }
// }
// }
 }


?>
