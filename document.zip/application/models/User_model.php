<?php
class User_model extends CI_model{

var $table = 'user';

public function register_user($user){


$this->db->insert('user', $user);

}

public function login_user($email,$pass){

  $this->db->select('*');
  $this->db->from('user');
  $this->db->where('user_email',$email);
  $this->db->where('user_password',$pass);

  if($query=$this->db->get())
  {
      return $query->row_array();
  }
  else{
    return false;
  }


}
public function email_check($email){

  $this->db->select('*');
  $this->db->from('user');
  $this->db->where('user_email',$email);
  $query=$this->db->get();

  if($query->num_rows()>0){
    return false;
  }else{
    return true;
  }

}
public function get_all_users()
{
$this->db->from('user');
$query=$this->db->get();
return $query->result();
}


	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('user_id',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function add_user($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	public function user_update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{
		$this->db->where('user_id', $id);
		$this->db->delete($this->table);
	}
  public function get_department()
  {
    $this->db->select('user_department');
    $this->db->from('user');
    $query=$this->db->get();
    return $query->result();
  }
public function create_folder($fold)
{
  $this->db->insert('folders',$fold);
}
public function list_folders()
{
  $this->db->select('department');
  $this->db->from('folders');
  $query=$this->db->get();
  return $query->result();

}

public function get_folder($uid1)
{
  $this->db->from('folders');
  $this->db->where('uid',$uid1);
  $query = $this->db->get();
  return $query->result();
}
public function list_files($postid)
{
$this->db->select('*');
$this->db->from('files');
$this->db->where('folder_name',$postid);
$query = $this->db->get();
return $query->result();
}
}



?>
