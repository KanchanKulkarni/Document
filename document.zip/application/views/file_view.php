<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html>
<head>
<style>
body {
background-color: lightblue;
}

input[type=text], select {
width: 50%;
padding: 12px 20px;
margin: 8px 0;
display: inline-block;
border: 1px solid #ccc;
border-radius: 4px;
box-sizing: border-box;
}

input[type=submit] {
width: 25%;
background-color: #4CAF50;
color: white;
padding: 14px 20px;
margin: 8px 0;
border: none;
border-radius: 4px;
cursor: pointer;
}
</style>
</head>
<title>Upload Form</title>
</head>
<body>
  <form action="<?php echo base_url() ?>index.php/User/save_file" method="post" enctype="multipart/form-data">
    <label for="filename">File Name</label>
        <input type="text" name="filename" placeholder="File name..">
         <br />
        <br />
        <label for="Doc type"></label>
            <input type="text" name="doctype" placeholder="Doctype..">
            <br />
    		<br />
        <label for="File description"></label>
            <input type="textarea" name="filedescription" rows="4" cols="50">
            <br />
    		<br />
Select file to upload:
     <input type="file" name="fileToUpload" id="fileToUpload">
     <input type="submit" value="save" name="submit">
     </form>
</body>
</html>




	
