<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="en">
<head>
<style>
ul {
    list-style-type: none;
    border-style: groove;
    padding: 20px;
}

</style>
</head>
<body>
<a href="<?php echo base_url('index.php/user/name_folders');?>" >  <button type="button" class="btn-primary">Create Folder</button></a>
<a href="<?php echo base_url('index.php/user/list_folders');?>" >  <button type="button" class="btn-primary">Back</button></a>
<div class="demo">
      <?php foreach($abc as $dep){?>
        <ul>
      <li><?php echo $dep->folder_name;?></li>
<?php $myfilename = $dep->folder_name; ?>
      <input type="submit" onclick="location.href='<?php echo base_url() ?>index.php/User/list_file/<?php echo $myfilename;?>';" value="Open" />

    </ul>

      <?php } ?>
</div>

</body>
</html>
