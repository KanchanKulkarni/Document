<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <style>
    fieldset {
      border: 0;
    }
    label {
      display: block;
      margin: 30px 0 0 0;
    }
    .overflow {
      height: 200px;
    }
  </style>
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#depart" ).selectmenu();


  } );
  </script>
</head>
<body>

<div class="demo">

<a href="<?php echo base_url('index.php/user/');?>"> <span class="glyphicon glyphicon-user"></span> Logout</a>

<form action="<?php echo base_url() ?>index.php/User/gett" method="post">
  <fieldset>
    <label for="department">Select a Department</label>
    <select name="depart" id="depart">
      <?php foreach($department as $dep){?>
      <option><?php echo $dep->department;?></option>

      <?php } ?>
    </select>
    <br><br>
    </fieldset>
<input type="submit" value="Load">
</form>
</div>

</body>
</html>
