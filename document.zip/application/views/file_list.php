<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="en">
<head>
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
</head>
<body>
 <a href="<?php echo base_url('index.php/user/gett');?>" >  <button type="button" class="btn-primary">Back</button></a>
<div class="demo">
  <br/><br/>
  <br/><br/>
  <table>
    <thead>
      <tr>
        <th>File ID</th>
        <th>File Name</th>
        <th>Folder Name</th>
        <th>File Type</th>
        <th>Description</th>

      </tr>
    </thead>
    <tbody>
      <?php foreach($xyz as $user){?>
           <tr>
               <td><?php echo $user->file_id;?></td>
               <td><?php echo $user->file_name;?></td>

              <td><?php echo $user->folder_name;?></td>
              <td><?php echo $user->file_type;?></td>
              <td><?php echo $user->description;?></td>
              </td>
            </tr>
           <?php }?>



    </tbody>
  </table>
</div>

</body>
</html>
