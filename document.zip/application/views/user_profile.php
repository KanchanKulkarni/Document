<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php
$user_id=$this->session->userdata('user_id');

if(!$user_id){

  redirect('user/login_view');
}

 ?>
 <!doctype html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>jQuery UI Selectmenu - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- <title>jQuery UI Tabs - Default functionality</title> -->
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <link href="http://localhost/CI/project/assests/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="http://localhost/CI/project/assests/datatables/css/dataTables.bootstrap.css" rel="stylesheet">
  <style>
    fieldset {
      border: 0;
    }
    label {
      display: block;
      margin: 30px 0 0 0;
    }
    .overflow {
      height: 200px;
    }
  </style>
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#tabs" ).tabs();
  } );
  $( function() {
    $( "#depart" ).selectmenu();


  } );
  </script>
</head>
<body>
  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand"></a>
      </div>

      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo base_url('index.php/user/user_logout');?>"> <span class="glyphicon glyphicon-user"></span> Logout</a></li>

      </ul>
    </div>
  </nav>

<div id="tabs">
  <ul>
    <li><a href="#tabs-1">Profile</a></li>
    <li><a href="#tabs-2">Document</a></li>
    <li><a href="#tabs-3">Folders</a></li>
  </ul>
  <div id="tabs-1">
    <table class="table table-bordered table-striped">


            <tr>
              <th colspan="2"><h4 class="text-center">User Info</h3></th>

            </tr>
              <tr>
                <td>User Name</td>
                <td><?php echo $this->session->userdata('user_name'); ?></td>
              </tr>
              <tr>
                <td>User Email</td>
                <td><?php echo $this->session->userdata('user_email');  ?></td>
              </tr>
              <tr>
                <td>User Role</td>
                <td><?php echo $this->session->userdata('user_role');  ?></td>
              </tr>
              <tr>
                <td>User Department</td>
                <td><?php echo $this->session->userdata('user_department');  ?></td>
              </tr>
          </table>
  </div>
  <div id="tabs-2">
<!-- documents -->
  </div>
  <div id="tabs-3">
  </center>
  <h3>user details</h3>
  <br />
  <button class="btn btn-success" onclick="add_user()"><i class="material-icons"></i> Create Folder</button>
  <br />
  <br />
  <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th>Folder List</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($user as $user){?>
           <tr>
               <td><?php echo $user->user_id;?></td>
               <td><?php echo $user->user_name;?></td>
               <td><?php echo $user->user_email;?></td>
              <td><?php echo $user->user_role;?></td>
              <td><?php echo $user->user_department;?></td>
              <td>
                <button class="btn btn-warning" onclick="edit_user(<?php echo $user->user_id;?>)"><i class="glyphicon glyphicon-pencil"></i></button>
                <button class="btn btn-danger" onclick="delete_user(<?php echo $user->user_id;?>)"><i class="glyphicon glyphicon-remove"></i></button>


              </td>
            </tr>
           <?php }?>



    </tbody>

    <tfoot>
      <tr>
        <th>User ID</th>
        <th>User Name</th>
        <th>User Email</th>
        <th>User Role</th>
        <th>User Department</th>

        <th>Action</th>
      </tr>
    </tfoot>
  </table>

  </div>

  <script src="http://localhost/CI/project/assests/jquery/jquery-3.1.0.min.js"></script>
  <script src="http://localhost/CI/project/assests/bootstrap/js/bootstrap.min.js"></script>
  <script src="http://localhost/CI/project/assests/datatables/js/jquery.dataTables.min.js"></script>
  <script src="http://localhost/CI/project/assests/datatables/js/dataTables.bootstrap.js"></script>


  <script type="text/javascript">
  $(document).ready( function () {
    $('#table_id').DataTable();
  } );
  var save_method; //for save method string
  var table;


  function add_user()
  {
    save_method = 'add';
    $('#form')[0].reset(); // reset form on modals
    $('#modal_form').modal('show'); // show bootstrap modal
  //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
  }

  // function edit_user(id)
  // {
  //   save_method = 'update';
  //   $('#form')[0].reset(); // reset form on modals
  //
  //   //Ajax Load data from ajax
  //   $.ajax({
  //     url : "<?php echo ('http://localhost/CI/project/index.php/User/ajax_edit/')?>/" + id,
  //     type: "GET",
  //     dataType: "JSON",
  //     success: function(data)
  //     {
  //
  //         $('[name="user_id"]').val(data.user_id);
  //         $('[name="user_name"]').val(data.user_name);
  //         $('[name="user_email"]').val(data.user_email);
  //         $('[name="user_password"]').val(data.user_password);
  //         $('[name="user_role"]').val(data.user_role);
  //         $('[name="user_department"]').val(data.user_department);
  //
  //         $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
  //         $('.modal-title').text('Edit User'); // Set title to Bootstrap modal title
  //
  //     },
  //     error: function (jqXHR, textStatus, errorThrown)
  //     {
  //         alert('Error get data from ajax');
  //     }
  // });
  // }



  function save()
  {
    var url;
    if(save_method == 'add')
    {
        url = "<?php echo ('http://localhost/CI/project/index.php/User/add_user')?>";
    }
    else
    {
      url = "<?php echo ('http://localhost/CI/project/index.php/User/user_update')?>";
    }

     // ajax adding data to database
        $.ajax({
          url : url,
          type: "POST",
          data: $('#form').serialize(),
          dataType: "JSON",
          success: function(data)
          {
             //if success close modal and reload ajax table
             $('#modal_form').modal('hide');
            location.reload();// for reload a page
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error adding / update data');
          }
      });
  }

  // function delete_user(id)
  // {
  //   if(confirm('Are you sure delete this data?'))
  //   {
  //     // ajax delete data from database
  //       $.ajax({
  //         url : "<?php echo ('http://localhost/CI/project/index.php/User/user_delete')?>/"+id,
  //         type: "POST",
  //         dataType: "JSON",
  //         success: function(data)
  //         {
  //
  //            location.reload();
  //         },
  //         error: function (jqXHR, textStatus, errorThrown)
  //         {
  //             alert('Error deleting data');
  //         }
  //     });
  //
  //   }
  // }

  </script>

  <!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
  <div class="modal-content">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <h3 class="modal-title">Create Folder</h3>
    </div>
    <div class="modal-body form">
      <form action="#" id="form" class="form-horizontal">
        <input type="hidden" value="" name="fold_id"/>
        <div class="form-body">
          <div class="form-group">
            <label class="control-label col-md-3">Folder Name</label>
            <div class="col-md-9">
              <input name="folder_name" placeholder=" Name" class="form-control" type="text">
            </div>
          </div>
          <fieldset>
            <label for="department">Select a Department</label>
            <select name="department" id="depart">
              <?php foreach($department as $dep){?>
              <option><?php echo $dep->user_department;?></option>

              <?php } ?>
              <option>test</option>
            </select>
            <br><br>
            </fieldset>



        </div>
      </form>
        </div>
        <div class="modal-footer">
          <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Create</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
        </div>

      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
  <!-- End Bootstrap modal -->



</div>


</body>
</html>
