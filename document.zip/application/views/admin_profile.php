<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php
$user_id=$this->session->userdata('user_id');

if(!$user_id){

  redirect('user/login_view');
}

 ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
   <title>Bootstrap Example</title>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   <style>
     /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
     .row.content {height: 1500px}

     /* Set gray background color and 100% height */
     .sidenav {
       background-color: #f1f1f1;
       height: 100%;
     }

     /* Set black background color, white text and some padding */
     footer {
       background-color: #555;
       color: white;
       padding: 15px;
     }

     /* On small screens, set height to 'auto' for sidenav and grid */
     @media screen and (max-width: 767px) {
       .sidenav {
         height: auto;
         padding: 15px;
       }
       .row.content {height: auto;}
     }
		 table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
   </style>
 </head>
 <body>
   <nav class="navbar navbar-inverse">
     <div class="container-fluid">
       <div class="navbar-header">
         <a class="navbar-brand">Document Management System</a>
       </div>
       <!-- <ul class="nav navbar-nav"> -->
         <!-- <li class="active"><a href="#">Home</a></li> -->
         <!-- <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1 <span class="caret"></span></a> -->
           <!-- <ul class="dropdown-menu"> -->
             <!-- <li><a href="#">Page 1-1</a></li> -->
             <!-- <li><a href="#">Page 1-2</a></li> -->
             <!-- <li><a href="#">Page 1-3</a></li> -->
           <!-- </ul> -->
         <!-- </li> -->
         <!-- <li><a href="#">Page 2</a></li> -->
       <!-- </ul> -->
       <ul class="nav navbar-nav navbar-right">
         <li><a href="<?php echo base_url('index.php/user/');?>"> <span class="glyphicon glyphicon-user"></span> Logout</a></li>
         <!-- <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li> -->
       </ul>
     </div>
   </nav>
 <div class="container-fluid">
   <div class="row content">
     <div class="col-sm-3 sidenav">

       <ul class="nav nav-pills nav-stacked">
         <li class="active"><a href="">Profile</a></li>
         <li><a href="<?php echo base_url() ?>index.php/User/details">Users</a></li>
         <!-- <li><a href="#section3">Family</a></li> -->
         <!-- <li><a href="#section3">Photos</a></li> -->
       </ul><br>

     </div>

     <div class="col-sm-9">
       <table class="table table-bordered table-striped">


               <tr>
                 <th colspan="2"><h4 class="text-center">User Info</h3></th>

               </tr>
                 <tr>
                   <td>User Name</td>
                   <td><?php echo $this->session->userdata('user_name'); ?></td>
                 </tr>
                 <tr>
                   <td>User Email</td>
                   <td><?php echo $this->session->userdata('user_email');  ?></td>
                 </tr>
                 <tr>
                   <td>User Role</td>
                   <td><?php echo $this->session->userdata('user_role');  ?></td>
                 </tr>
                 <tr>
                   <td>User Department</td>
                   <td><?php echo $this->session->userdata('user_department');  ?></td>
                 </tr>
             </table>
 </div>
</div>
</div>

</div>


 </body>
 </html>
