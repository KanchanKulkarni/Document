-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 27, 2017 at 12:52 PM
-- Server version: 5.7.18-0ubuntu0.16.04.1
-- PHP Version: 7.0.15-0ubuntu0.16.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `document`
--

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `file_id` int(11) NOT NULL,
  `file_name` varchar(250) DEFAULT NULL,
  `file_path` varchar(1000) DEFAULT NULL,
  `folder_name` varchar(250) DEFAULT NULL,
  `file_type` varchar(250) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`file_id`, `file_name`, `file_path`, `folder_name`, `file_type`, `description`) VALUES
(1, 'pdf', '/var/www/html/CI/project/demo1/pdf.pdf', 'demo1', 'pdf', 'demo'),
(2, 'pdf-test', '/var/www/html/CI/project/demo1/pdf-test.pdf', 'demo1', 'pdf', 'try'),
(3, 'pdf', '/var/www/html/CI/project/demo2/pdf.pdf', 'demo2', 'pdf', 'demo'),
(4, 'pdf-test', '/var/www/html/CI/project/demo2/pdf-test.pdf', 'demo2', 'pdf', 'try'),
(5, 'pdf', '/var/www/html/CI/project/dggdfgdfh/pdf.pdf', 'dggdfgdfh', 'pdf', 'demo'),
(6, 'pdf-test', '/var/www/html/CI/project/dggdfgdfh/pdf-test.pdf', 'dggdfgdfh', 'pdf', 'try'),
(7, 'pdf', '/var/www/html/CI/project/list/pdf.pdf', 'list', 'pdf', 'demo'),
(8, 'pdf-test', '/var/www/html/CI/project/list/pdf-test.pdf', 'list', 'pdf', 'try'),
(9, 'pdf', '/var/www/html/CI/project/new/pdf.pdf', 'new', 'pdf', 'demo'),
(10, 'pdf-test', '/var/www/html/CI/project/new/pdf-test.pdf', 'new', 'pdf', 'try');

-- --------------------------------------------------------

--
-- Table structure for table `folders`
--

CREATE TABLE `folders` (
  `fold_id` int(11) NOT NULL,
  `department` varchar(250) DEFAULT NULL,
  `folder_path` varchar(1000) DEFAULT NULL,
  `uid` varchar(45) DEFAULT NULL,
  `folder_name` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `folders`
--

INSERT INTO `folders` (`fold_id`, `department`, `folder_path`, `uid`, `folder_name`) VALUES
(16, 'Hr', '/var/www/html/CI/project/dggdfgdfh/', '11', 'dggdfgdfh'),
(17, 'Testing', '/var/www/html/CI/project/list/', '11', 'list'),
(18, 'Development', '/var/www/html/CI/project/demo1/', '11', 'demo1'),
(22, 'Testing', '/var/www/html/CI/project/new/', '11', 'new'),
(23, 'Development', '/var/www/html/CI/project/new1/', '11', 'new1'),
(24, 'Development', '/var/www/html/CI/project/dggdfgdfh/', '11', 'dggdfgdfh'),
(25, 'Designing', '/var/www/html/CI/project/demo6/', '11', 'demo6'),
(26, 'Development', '/var/www/html/CI/project/list4/', '11', 'list4'),
(27, 'Development', '/var/www/html/CI/project/list5/', '11', 'list5'),
(38, 'Development', '/var/www/html/CI/project/jdfrf/', '11', 'jdfrf'),
(39, 'Testing', '/var/www/html/CI/project/hrf/', '11', 'hrf'),
(40, 'Testing', '/var/www/html/CI/project/try/', '11', 'try'),
(41, 'Testing', '/var/www/html/CI/project/jert/', '11', 'jert'),
(42, 'Marketing', '/var/www/html/CI/project/deee/', '11', 'deee');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(250) DEFAULT NULL,
  `user_email` varchar(250) DEFAULT NULL,
  `user_password` varchar(250) DEFAULT NULL,
  `user_role` varchar(250) DEFAULT NULL,
  `user_department` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_password`, `user_role`, `user_department`) VALUES
(1, 'Admin', 'testmgr@test.com', 'testmgr123', 'Admin', 'Hr'),
(10, 'Test User', 'testusr@tset.com', 'testusr123', 'User', 'Testing'),
(11, 'Kanchan', 'kanchan@gmail.com', '123', 'User', 'Development'),
(12, 'priya1', 'priya@gmail.com', '123456', 'User', 'Designing'),
(13, 'Harsh', 'harsha@gmail.com', '123456', 'User', 'Marketing');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `folders`
--
ALTER TABLE `folders`
  ADD PRIMARY KEY (`fold_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `folders`
--
ALTER TABLE `folders`
  MODIFY `fold_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
